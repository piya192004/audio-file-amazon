# Piya_chhabra
# A01387227


def get_book_info():
    """
    ask the user for book information
    :returns a string that contain all the book information
    """

    title = input("Enter book title: ").strip().title()
    isbn = input("Enter book ISBN: ").strip()
    author_last_name = input("Enter author last name: ").strip().capitalize()
    year_published = input("Enter year published: ").strip()
    price = "{:.2f}".format(float(input("Enter price: ").strip()))

    return f"{title}/{isbn}/{author_last_name}/{year_published}/{price}"


def to_csv_format(book_info):
    """
    Converting the book info string to CSV format.
    """
    return book_info.replace("/", ",")


def to_json_format(csv_format):
    """
    Converting the CSV formatted string to JSON format.
    """
    elements = csv_format.split(",")
    json_format = f'{{"title":"{elements[0]}","isbn":"{elements[1]}","author_last_name":"{elements[2]}","year_published":"{elements[3]}","price":"{elements[4]}"}}'
    return json_format


def main():
    book_info = get_book_info()
    csv_format = to_csv_format(book_info)
    json_format = to_json_format(csv_format)

    print("The CSV Format String:")
    print(csv_format)
    print("The JSON Format String:")
    print(json_format)


if __name__ == "__main__":
    main()
