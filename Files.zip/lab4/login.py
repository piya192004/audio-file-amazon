# Piya_chhabra
# A01387227
def generate_password(first_name, last_name, bcit_id):
    """
    generating a default password according to user details
    Returns: the first three letters of first name, last name, and the last three letters of bcit id
    """
    format_first_name = first_name.capitalize()
    format_last_name = last_name.capitalize()
    first_name_part = format_first_name[:3]
    last_name_part = format_last_name[:3]
    bcit_id_result = bcit_id[-3:]
    password = first_name_part + last_name_part + bcit_id_result
    return password


def has_upper(password):
    """
    To check if the password contains any uppercase letter
    :returns true if it contains an uppercase letter otherwise false
    """
    return any(char.isupper() for char in password)


def has_lower(password):
    """
    To check if the password contains any lowercase letter
    :returns true if it contains an lowercase letter otherwise false

    """
    return any(char.islower() for char in password)


def has_digit(password):
    """
    To check if the password contains at least one digit
    :returns true if contains at least one digit otherwise false
    """
    return any(char.isdigit() for char in password)


def no_special_chars(password):
    """
    To check if the password contains any special character
    :returns true if does not have any special character otherwise false
    """
    return all(char.isalnum() for char in password)


def valid_password(password):
    """
    To check if meets all the requirements
    True if the password is at least 7 characters long, at least one uppercase letter, one lowercase letter, one digit, and no special characters. False otherwise.
    """
    if (len(password) >= 7
            and has_upper(password)
            and has_lower(password)
            and has_digit(password)
            and no_special_chars(password)):
        return True
    else:
        return False


def change_password():
    """Prompts the user for a new password until it meets the requirements."""
    while True:
        password = input('Enter a new password: ')
        if len(password) < 7:
            print("The password must be at least 7 characters long.")
        elif not has_upper(password):
            print("The password must have at least one uppercase letter.")
        elif not has_lower(password):
            print("The password must have at least one lowercase letter.")
        elif not has_digit(password):
            print("The password must have at least one number.")
        elif not no_special_chars(password):
            print("Special characters are not allowed.")
        else:
            print("Valid password")
            return password


first = input('enter your first name:')
last = input('enter your last name:')
id_part = input('enter your bcit_id:')
login_id = generate_password(first, last, id_part)
print(f'your login id is {login_id}')
new_password = change_password()
print(new_password)
