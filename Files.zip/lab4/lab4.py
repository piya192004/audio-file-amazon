# piya chhabra
# A01387227

import login


def main():
    # Asking user for details:
    first_name = input("Enter your first name: ")
    last_name = input("Enter your last name: ")
    bcit_id = input("Enter your BCIT ID: ")

# Generating default password
    default_password = login.generate_password(first_name, last_name, bcit_id)
    print(f"Your default password is: {default_password}")

# to change password, setting up everything
    new_password = login.change_password()
    print(f"Your new password is: {new_password}")


if __name__ == "__main__":
    main()
